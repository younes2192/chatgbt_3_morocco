How to host on server? 
Well, I would say, First install pm2
Then run: pm2 start index.js
then Run: pm2 save
Then run: sartup
Then just restart your server.
